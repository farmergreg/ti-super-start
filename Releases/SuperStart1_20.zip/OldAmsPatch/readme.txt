This is an advanced patch which allows super start to run on ams 2.00 - 2.03.

Steps:
1. Install KerNO
2. Install Super Start
3. Execute This Patch
4. Sit back, and enjoy...


-Greg