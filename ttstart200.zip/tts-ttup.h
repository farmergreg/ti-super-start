| TIGCC Program Starter - ttunpack decompression support
| Copyright (C) 2004-2005 Samuel Stearley, Kevin Kofler
|
| THE LISCENSE:
|
|   The liscense is quite similar to that of the origional version in c.
|
|   The code may be freely used in any non commercial application.  If
|   you do use it please give credit to tict (http://tict.ticalc.org) and
|   myself (Samuel Stearley).  I state this as a request but it is actually
|   not.
|
|   The author(s) (Samuel/Tict/Any other contributor) make no
|   representations or warranties about the suitability of the software,
|   either express or implied. The author(s) shall not be liable for
|   any damages suffered as a result of using or distributing this
|   software.
|
|   If you distribute this file on a website or as part of
|   the source of a project do not remove the liscense or the notes
|   from this file.

.text
ttunpack_decompress:
	.word	18663
	.word	7998
	.word	11375
	.word	44
	.word	10863
	.word	48
	.word	18414
	.word	15
	.word	6702
	.word	6
	.word	32384
	.word	28676
	.word	21646
	.word	3102
	.word	84
	.word	26156
	.word	3094
	.word	80
	.word	26150
	.word	29192
	.word	28679
	.word	23694
	.word	6174
	.word	-18431
	.word	25626
	.word	28678
	.word	-19938
	.word	26132
	.word	-16866
	.word	26128
	.word	4627
	.word	17395
	.word	4097
	.word	7193
	.word	28677
	.word	3094
	.word	5
	.word	25878
	.word	17408
	.word	19679
	.word	31992
	.word	20085
	.word	4612
	.word	24892
	.word	-16059
	.word	29192
	.word	-28156
	.word	24898
	.word	6848
	.word	4612
	.word	26374
	.word	24876
	.word	-20475
	.word	26350
	.word	24892
	.word	13824
	.word	21312
	.word	26440
	.word	24884
	.word	20992
	.word	26578
	.word	21760
	.word	4651
	.word	-3
	.word	24864
	.word	29191
	.word	24850
	.word	17920
	.word	17536
	.word	6901
	.word	2303
	.word	20939
	.word	-6
	.word	24782
	.word	28672
	.word	24586
	.word	-9210
	.word	-11968
	.word	-7649
	.word	25602
	.word	7193
	.word	21249
	.word	27378
	.word	17600
	.word	20085
	.word	29702
	.word	29439
	.word	25064
	.word	21706
	.word	-4
	.word	29190
	.word	-28094
	.word	28673
	.word	24806
	.word	25050
	.word	25794
	.word	25046
	.word	25744
	.word	25060
	.word	5632
	.word	27148
	.word	25036
	.word	16128
	.word	25050
	.word	21248
	.word	7808
	.word	13855
	.word	25042
	.word	3072
	.word	32
	.word	25606
	.word	4147
	.word	0
	.word	24580
	.word	29186
	.word	25008
	.word	6848
	.word	28672
	.word	24736
