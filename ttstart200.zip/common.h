| TIGCC Tools Suite Program Starter - code common to at least two
| decompression routines.
| Copyright 2005 Kevin Kofler (original code), Lionel Debroux (adaptation).

| GET_UNCOMPRESSED_SIZE_PROLOGUE inline function
| INPUT: %a3.l: pointer to compressed data
| OUTPUT: %d6.l: uncompressed size;
|         a1.l: pointer to the variable's data type.
| SIDE EFFECTS: sets d1 to 0.
| DESTROYS: %d0-%d1/%a0
.macro GET_UNCOMPRESSED_SIZE_PROLOGUE
| Get the length of the variable.
moveq.l #0,%d6
move.w (%a3)+,%d6
| Get a pointer to the data type of the variable.
lea.l -1(%a3,%d6.l),%a0
| Check if archive
cmpi.b #0xF8,(%a0) | OTH_TAG
.ifdef asmsupport
jbeq archive
cmpi.b #0xF3,(%a0) | ASM_TAG
.endif
jbne invalid_archive_or_prgm
.ifdef asmsupport
| ASM program, must be treated differently.
moveq #4,%d5
jra gus_epilogue
archive:
.endif
tst.b -(%a0)
jbne invalid_archive_or_prgm
| No type was found yet.
clr.w %d5
| Save pointer to end of data type.
move.l %a0,%a1
.endm

.macro GET_UNCOMPRESSED_SIZE_EPILOGUE
gus_epilogue:
tst.w %d5
jbne valid_archive
| Type not supported.
invalid_archive_or_prgm:
.word 0xA000+210 | ER_DATATYPE
valid_archive:
.ifdef asmsupport
cmpi.w #4,%d5
jbne notasmprgm
| d5 = 4 <=> ASM program.
asmprgm:
| Not necessary on the Titanium, bail out.
tst.b %d7
jbne invalid_archive_or_prgm

subq.l #2,%a3 | Get back to the beginning of the two size bytes.
addq.w #2,%d6 | Add two bytes.
cmpa.l #0x1FFFFF,%a3
bcc.s end_gus_epilogue | Already in RAM, no need to allocate ?
clr.w -(%a2) | No handle to allocate/free.
bra.s before_launch
notasmprgm:

.endif
end_gus_epilogue:
.endm

.macro MEM_TO_MEM_COPY_ASM
| OK because it is always the first routine.
cmpi.w #4,%d5
bne.s endmmca
move.l %d6,-(%sp) | Size
pea.l (%a3) | source
pea.l (%a0) | destination
move.l %a0,%a3 | satisfy output constraint
move.l 0x26A*4(%a5),%a0 | memcpy
jsr (%a0)
lea 12(%sp),%sp
endmmca:
.endm


| GET_UNCOMPRESSED_SIZE_PPG inline function
| INPUT: %a3.l: pointer to compressed data
| OUTPUT: %d6.l: uncompressed size
| SIDE EFFECTS: none.
| DESTROYS: %d0-%d1/%a0
.macro GET_UNCOMPRESSED_SIZE_PPG
| No need to move a1 to a0 (always the first routine).
| Check if it has type "ppg".
cmp.b #'g',-(%a0)
jbne notppg
moveq.l #'p',%d0
cmp.b -(%a0),%d0
jbne notppg
cmp.b -(%a0),%d0
jbne notppg
tst.b -(%a0)
jbne notppg
| We don't need to check the magic number in the ttunpack header,
| the decompression routine does that already.
| We have a PPG file.
moveq #1,%d5
| Get the uncompressed size.
move.w (%a3),%d6
rol.w #8,%d6
.ifndef lzma
jbra gus_epilogue
.endif
notppg:
endguppg:
.endm

| MEM_TO_MEM_DECOMPRESS_PPG inline function
| INPUT: %a3.l: pointer to compressed data
|        %a0.l: pointer to buffer for uncompressed data
|        %d6.l: uncompressed size
| OUTPUT: %a3.l: pointer to uncompressed data
| SIDE EFFECTS: may throw a Memory or Data Type error
| DESTROYS: %d0-%d2/%a0-%a2
.macro MEM_TO_MEM_DECOMPRESS_PPG
| OK because it is always the first routine.
cmpi.w #1,%d5
bne.s endmdppg
pea.l (%a0) | destination
pea.l (%a3) | source
move.l %a0,%a3 | satisfy output constraint
jbsr ttunpack_decompress
addq.l #8,%a7
tst.w %d0
jbne invalid_archive_or_prgm
endmdppg:
.endm

